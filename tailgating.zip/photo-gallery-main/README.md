## Tailgating Detection Web App

This folder contains a complete demo application for detecting tailgating / unauthorized entry using a webcam, with a modern web dashboard, Flask backend, and MongoDB database.

- **Frontend**: `templates/index.html` + assets in `static/`
- **Backend**: Flask app in `backend/app.py`
- **Database**: MongoDB database (by default `tailgating`), managed by `backend/db.py`

### 1. Install dependencies

Use Python 3.11+ and create a virtual environment if you like, then (make sure MongoDB is installed and running locally or available via a connection URI):

```bash
cd c:\photo-gallery
pip install -r requirements.txt
```

### 2. Run the backend

From the project root:

```bash
cd backend
python app.py
```

The app will:

- Ensure MongoDB collections and indexes exist (if needed).
- Start a Flask + Socket.IO server on `http://127.0.0.1:5000/`.

### 3. Open the dashboard

Visit `http://127.0.0.1:5000/` in your browser.  
You’ll see:

- A **Simulate Access Event** card (to send access events into the system).
- A **Real‑time Alerts** panel for tailgating alerts.
- A **Recent Incidents** list with screenshots saved to `static/screenshots/`.
- A **Door Activity Overview** chart summarizing people counts from incidents.

### 4. How the backend & database work

- `backend/app.py` exposes:
  - `POST /api/access` &mdash; logs an access event, starts a short webcam scan, and emits an alert if more people are detected than authorized.
  - `GET /api/incidents` &mdash; returns recent incidents stored in MongoDB.
  - `GET /api/logs` &mdash; returns access logs stored in MongoDB.
- `backend/db.py` manages the MongoDB database:
  - Uses `MONGO_URI` env var if set, otherwise defaults to `mongodb://localhost:27017`.
  - Uses database name from `MONGO_DB_NAME` env var if set, otherwise `tailgating`.
  - Collections:
    - `incidents(timestamp, people_count, authorized_count, screenshot_path)`
    - `access_logs(timestamp, method, authorized_count)`

You can inspect the database directly using any MongoDB client (e.g., `mongosh`, Compass) by connecting to the Mongo instance and opening the `tailgating` database.

#   A I - t a i l g a t i n g  
 
import os
from datetime import datetime

from pymongo import MongoClient, ASCENDING, DESCENDING


def _get_client() -> MongoClient:
    """
    Return a MongoDB client.

    Uses MONGO_URI env var if set, otherwise defaults to a local instance.
    """
    uri = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    return MongoClient(uri)


def _get_db():
    client = _get_client()
    db_name = os.getenv("MONGO_DB_NAME", "tailgating")
    return client[db_name]


def init_db():
    """
    Ensure MongoDB collections and indexes exist.

    No schema is enforced, but we create indexes on timestamp for fast sorting.
    """
    db = _get_db()
    db.incidents.create_index([("timestamp", DESCENDING)])
    db.access_logs.create_index([("timestamp", DESCENDING)])


def log_access(method: str, authorized_count: int) -> None:
    """Insert an access log entry."""
    db = _get_db()
    db.access_logs.insert_one(
        {
            "timestamp": datetime.now().isoformat(),
            "method": method,
            "authorized_count": int(authorized_count),
        }
    )


def log_incident(people_count: int, authorized_count: int, screenshot_path: str) -> None:
    """Insert an incident entry."""
    db = _get_db()
    db.incidents.insert_one(
        {
            "timestamp": datetime.now().isoformat(),
            "people_count": int(people_count),
            "authorized_count": int(authorized_count),
            "screenshot_path": screenshot_path,
        }
    )


def get_incidents():
    """
    Return incidents in the same list-of-lists shape the frontend expects.

    Each incident is:
    [id, timestamp, people_count, authorized_count, screenshot_path]
    """
    db = _get_db()
    cursor = db.incidents.find().sort("timestamp", DESCENDING)
    results = []
    for doc in cursor:
        results.append(
            [
                str(doc.get("_id")),
                doc.get("timestamp"),
                doc.get("people_count"),
                doc.get("authorized_count"),
                doc.get("screenshot_path"),
            ]
        )
    return results


def get_access_logs():
    """
    Return access logs as list-of-lists for compatibility:

    [id, timestamp, method, authorized_count]
    """
    db = _get_db()
    cursor = db.access_logs.find().sort("timestamp", DESCENDING)
    results = []
    for doc in cursor:
        results.append(
            [
                str(doc.get("_id")),
                doc.get("timestamp"),
                doc.get("method"),
                doc.get("authorized_count"),
            ]
        )
    return results
import cv2
import numpy as np
from collections import defaultdict

class PeopleDetector:
    def __init__(self):
        self.subtractor = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=50, detectShadows=True)
        self.line_y = 240  # Assume frame height 480, line at middle
        self.min_contour_area = 500
        self.crossed = set()
        self.count = 0

    def detect_and_count(self, frame):
        fg_mask = self.subtractor.apply(frame)
        fg_mask = cv2.medianBlur(fg_mask, 5)
        _, thresh = cv2.threshold(fg_mask, 127, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        current_centers = []
        for contour in contours:
            if cv2.contourArea(contour) > self.min_contour_area:
                x, y, w, h = cv2.boundingRect(contour)
                center_y = y + h // 2
                current_centers.append(center_y)

        # Simple crossing detection: if center crosses line
        for center_y in current_centers:
            if center_y > self.line_y and center_y not in self.crossed:
                self.crossed.add(center_y)
                self.count += 1

        return self.count, frame

    def reset(self):
        self.crossed = set()
        self.count = 0
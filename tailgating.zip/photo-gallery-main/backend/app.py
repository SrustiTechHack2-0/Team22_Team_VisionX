from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
import cv2
import threading
import time
import os
from people_detector import PeopleDetector
from db import init_db, log_access, log_incident, get_incidents, get_access_logs
from datetime import datetime

app = Flask(__name__, template_folder='../templates', static_folder='../static')
socketio = SocketIO(app, cors_allowed_origins="*")

detector = PeopleDetector()
processing = False

@app.route('/')
def dashboard():
    return render_template('index.html')

@app.route('/api/access', methods=['POST'])
def access_event():
    global processing
    if processing:
        return jsonify({'status': 'busy'}), 400

    data = request.json
    method = data.get('method', 'RFID')
    authorized_count = data.get('authorized_count', 1)

    log_access(method, authorized_count)

    # Start detection thread
    processing = True
    thread = threading.Thread(target=process_entry, args=(authorized_count,))
    thread.start()

    return jsonify({'status': 'started'})

def process_entry(authorized_count):
    global processing
    cap = cv2.VideoCapture(0)  # Webcam
    if not cap.isOpened():
        print("Cannot open camera")
        processing = False
        return

    start_time = time.time()
    duration = 8  # seconds
    people_count = 0
    detector.reset()

    while time.time() - start_time < duration:
        ret, frame = cap.read()
        if not ret:
            break

        count, processed_frame = detector.detect_and_count(frame)
        people_count = count

        # Display for demo
        cv2.line(processed_frame, (0, detector.line_y), (640, detector.line_y), (0, 255, 0), 2)
        cv2.putText(processed_frame, f'Count: {count}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.imshow('Detection', processed_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    if people_count > authorized_count:
        # Capture screenshot
        screenshot_path = f"screenshots/incident_{int(time.time())}.jpg"
        os.makedirs('static/screenshots', exist_ok=True)
        cv2.imwrite(f'static/{screenshot_path}', processed_frame)

        log_incident(people_count, authorized_count, screenshot_path)

        # Emit alert
        socketio.emit('alert', {
            'message': f'Tailgating detected! {people_count} people entered, authorized: {authorized_count}',
            'screenshot': screenshot_path,
            'timestamp': datetime.now().isoformat()
        })

    processing = False

@app.route('/api/incidents')
def get_incidents_api():
    incidents = get_incidents()
    return jsonify(incidents)

@app.route('/api/logs')
def get_logs_api():
    logs = get_access_logs()
    return jsonify(logs)

if __name__ == '__main__':
    init_db()
    socketio.run(app, debug=True)
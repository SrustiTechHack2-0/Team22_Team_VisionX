const socket = io();
let incidents = [];
let statsChart = null;

// Elements
const alertBox = document.getElementById('alertBox');
const alertMessage = document.getElementById('alertMessage');
const incidentsContainer = document.getElementById('incidents');
const incidentsEmptyState = document.getElementById('incidentsEmptyState');
const statsEmptyState = document.getElementById('statsEmptyState');
const triggerButton = document.getElementById('triggerButton');
const statusDot = document.getElementById('systemStatusDot');
const statusLabel = document.getElementById('systemStatusLabel');

function setSystemStatus(label, isActive) {
    statusLabel.textContent = label;
    if (isActive) {
        statusDot.classList.add('status-dot--active');
    } else {
        statusDot.classList.remove('status-dot--active');
    }
}

function showAlert(message) {
    if (!alertBox || !alertMessage) return;
    alertBox.classList.remove('alert--hidden');
    alertMessage.textContent = message;
}

// Socket events
socket.on('alert', function (data) {
    showAlert(data.message);
    setSystemStatus('Tailgating detected', false);
    loadIncidents();
});

// Actions
function triggerAccess() {
    const method = document.getElementById('method').value;
    const authCount = parseInt(document.getElementById('authCount').value || '1', 10);

    triggerButton.disabled = true;
    setSystemStatus('Scanning for tailgating…', true);
    showAlert('Monitoring doorway for potential tailgating…');

    fetch('/api/access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method, authorized_count: authCount })
    })
        .then(res => {
            if (!res.ok) {
                return res.json().catch(() => ({})).then(body => {
                    throw new Error(body.status || 'System is busy');
                });
            }
            return res.json();
        })
        .then(() => {
            // Back-end will emit alert if an incident is detected.
            setTimeout(() => {
                triggerButton.disabled = false;
                setSystemStatus('Idle', false);
            }, 9000);
        })
        .catch(err => {
            triggerButton.disabled = false;
            setSystemStatus('Idle', false);
            showAlert(`Could not start detection: ${err.message}`);
        });
}

// Data loading
function loadIncidents() {
    fetch('/api/incidents')
        .then(res => res.json())
        .then(data => {
            incidents = data || [];
            updateIncidents();
            updateChart();
        })
        .catch(() => {
            // silently ignore for now in the demo
        });
}

// Rendering
function updateIncidents() {
    if (!incidentsContainer) return;
    const latest = incidents.slice(0, 5);

    if (latest.length === 0) {
        incidentsContainer.innerHTML = '';
        if (incidentsEmptyState) incidentsEmptyState.style.display = 'block';
        return;
    }

    if (incidentsEmptyState) incidentsEmptyState.style.display = 'none';

    incidentsContainer.innerHTML = latest
        .map(inc => {
            const timestamp = inc[1];
            const peopleCount = inc[2];
            const authorized = inc[3];
            const path = inc[4]; // e.g. "screenshots/incident_xxx.jpg"
            const imageUrl = `/static/${path}`;

            const dateStr = new Date(timestamp).toLocaleString();

            return `
                <article class="incident">
                    <div class="incident__meta">
                        <span class="incident__time">${dateStr}</span>
                        <span class="incident__details">
                            <span class="incident__badge">
                                <span class="incident__badge-dot"></span>
                                Tailgating incident
                            </span>
                            &nbsp;${peopleCount} people entered, authorized: ${authorized}
                        </span>
                    </div>
                    <div class="incident__image-wrapper">
                        <img class="incident__image" src="${imageUrl}" alt="Tailgating incident snapshot">
                    </div>
                </article>
            `;
        })
        .join('');
}

function updateChart() {
    const canvas = document.getElementById('statsChart');
    if (!canvas) return;

    const hasData = incidents.length > 0;

    if (!hasData) {
        if (statsEmptyState) statsEmptyState.style.display = 'block';
        if (statsChart) {
            statsChart.destroy();
            statsChart = null;
        }
        return;
    }

    if (statsEmptyState) statsEmptyState.style.display = 'none';

    const ctx = canvas.getContext('2d');
    const labels = incidents.map(inc => new Date(inc[1]).toLocaleDateString());
    const data = incidents.map(inc => inc[2]);

    if (statsChart) {
        statsChart.data.labels = labels;
        statsChart.data.datasets[0].data = data;
        statsChart.update();
        return;
    }

    statsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'People per incident',
                data,
                borderColor: '#f97316',
                backgroundColor: 'rgba(248, 113, 113, 0.12)',
                borderWidth: 2,
                tension: 0.25,
                pointRadius: 3,
                pointBackgroundColor: '#fed7aa',
                pointBorderColor: '#f97316',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#9ca3af',
                        font: { size: 11 }
                    },
                    grid: {
                        color: 'rgba(55, 65, 81, 0.5)'
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#9ca3af',
                        font: { size: 11 },
                        precision: 0
                    },
                    grid: {
                        color: 'rgba(55, 65, 81, 0.5)'
                    }
                }
            }
        }
    });
}

// Initial load
if (alertBox && alertMessage) {
    alertBox.classList.add('alert--hidden');
}
setSystemStatus('Idle', false);
loadIncidents();
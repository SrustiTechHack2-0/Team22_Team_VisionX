# Models Directory

This directory is reserved for AI/ML models used in the system.

Currently, the system uses OpenCV's built-in background subtraction (MOG2) for people detection, which doesn't require pre-trained model files.

For future enhancements:
- YOLOv8 models for more accurate person detection
- MobileNet-SSD models for lightweight inference
- Custom ML models for suspicious behavior classification

To add a model:
1. Download the model weights and config files
2. Place them in this directory
3. Update the people_detector.py to load and use the model
# Frontend Directory

This directory is for additional frontend assets if needed.

Currently, the frontend is served by Flask from the templates/ directory.

For a separate frontend (e.g., React/Vue), you could place the build files here and configure Flask to serve them.

Current structure:
- templates/index.html: Main dashboard
- static/css/style.css: Styles
- static/js/app.js: JavaScript logic